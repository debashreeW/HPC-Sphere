package main

import "fmt"

func swap(x, y string) (string, string) {
	return y, x
}
func main() {
	a, b := "Mahesh", "Kumar"
	fmt.Println("Before swapping :-\n", a, b)
	a, b = swap(a, b)
	fmt.Println("After swapping :-\n", a, b)

	findQuoRem := func(dd, dr int) (int, int) { // Defining function as anonymous func of JS
		return (dd / dr), (dd % dr)
	}
	quotient, remainder := findQuoRem(37, 6)
	fmt.Println(quotient, "", remainder)
}
