package main

import "fmt"

func main() {
	/* my first program in Go */
	fmt.Println("Hello, World!")
}
