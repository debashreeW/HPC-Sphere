//WAP to fine prime no's between 2 to 50

package main

import "fmt"

func main() {
	var i, j int
	count := 0

	for i = 2; i < 50; i++ {
		for j = 2; j <= (i / j); j++ {
			if i%j == 0 {
				break // if factor found, not prime
			}
		}
		if j > (i / j) {
			fmt.Printf("%d is prime\n", i)
			count++
		}
	}
	fmt.Printf("There are total %d prime no's between 2 and 50!\n", count)
}
