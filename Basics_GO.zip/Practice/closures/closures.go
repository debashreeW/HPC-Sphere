package main

import "fmt"

func main() {
	fmt.Println("Calling outer from 1st reference...")
	outerCall := outer()
	fmt.Println("a = ", outerCall())
	fmt.Println("a = ", outerCall())
	fmt.Println("a = ", outerCall())

	fmt.Println("Calling outer from 2nd reference...") // a is reset as new context of a is built
	anotherCall := outer()
	fmt.Println("a = ", anotherCall())
	fmt.Println("a = ", anotherCall())
}

func outer() func() int {
	a := 0
	return func() int {
		a++
		return a
	}
}
