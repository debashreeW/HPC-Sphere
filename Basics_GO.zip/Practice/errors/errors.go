package main

import (
	"errors"
	"fmt"
	"math"
)

func main() {
	// var num float64 = -1
	var num float64 = 16
	val, err := SquareRoot(num)
	if val > 0 {
		fmt.Printf("The square root of %v is %v", num, val)
	} else {
		fmt.Println(err)
	}
}
func SquareRoot(n float64) (float64, error) {
	if n < 0 {
		return 0, errors.New("cant find squareroot of negative number")
	} else {
		return math.Sqrt(n), nil
	}
}
