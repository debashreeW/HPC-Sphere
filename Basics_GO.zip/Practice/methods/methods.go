// Methods are special functions with a receiver.

package main

import (
	"fmt"
	"math"
)

const PI = 3.14

type Rect struct {
	l, b float64
}

type Circ struct {
	r float64
}

func (r Rect) area() float64 {
	return r.l * r.b
}

func (c Circ) area() float64 {
	return PI * c.r * c.r
}

// Same area() is being called by different types - think of it like method overloading

func main() {
	r := Rect{10, 15}
	c := Circ{7}
	fmt.Println("Area of rectangle = ", r.area())
	fmt.Println("Area of Circle = ", math.Round(c.area()))
}
