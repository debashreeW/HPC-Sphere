package main

import "fmt"

func main() {
	// Existing slice
	sl1 := []int{10, 20, 30, 40, 50}
	fmt.Printf("Slice : %v Length : %d Capacity : %d\n", sl1, len(sl1), cap(sl1))

	fmt.Println("Capacity Doubled------>")
	sl2 := make([]int, len(sl1), cap(sl1)*2)
	copy(sl2, sl1)
	fmt.Printf("Slice : %v Length : %d Capacity : %d\n", sl2, len(sl2), cap(sl2))

	fmt.Println("Length Doubled------>")
	sl3 := make([]int, len(sl1)*2, cap(sl1)*2)
	copy(sl3, sl1)
	fmt.Printf("Slice : %v Length : %d Capacity : %d\n", sl3, len(sl3), cap(sl3))
}
