package main

import "fmt"

func main() {
	var grade string
	var marks int = 91

	switch { // switch may not have any variable in-line to test
	case marks >= 90: // no need of writing "break" in cases for switch
		grade = "A"
	case marks < 90 && marks >= 80:
		grade = "B"
	case marks < 80 && marks >= 50:
		grade = "C"
	case marks < 50 && marks >= 33:
		grade = "D"
	default:
		grade = "F"
	}
	switch grade {
	case "A":
		fmt.Printf("Excellent!\n")
	case "B", "C":
		fmt.Printf("Well done\n")
	case "D":
		fmt.Printf("You passed\n")
	case "F":
		fmt.Printf("Better try again\n")
	default:
		fmt.Printf("Invalid grade\n")
	}
	fmt.Printf("Your grade is  %s\n", grade)

	typeSwitch()
}

func typeSwitch() {
	var x interface{}
	switch i := x.(type) { // Type Switch - only takes variable of interface type
	case nil:
		fmt.Printf("type of x :%T", i)
	case int:
		fmt.Printf("x is int")
	case float64:
		fmt.Printf("x is float64")
	case func(int) float64:
		fmt.Printf("x is func(int)")
	case bool, string:
		fmt.Printf("x is bool or string")
	default:
		fmt.Printf("don't know the type")
	}
}

// There are select statements like switches - more advanced topic channels
