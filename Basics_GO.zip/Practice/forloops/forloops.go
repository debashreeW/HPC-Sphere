package main

import "fmt"

func main() {
	var b int = 10
	var a int

	numbers := [6]int{10, 20, 30, 50} // capacity of 6 but only 4 initialized, rest all by default zero

	for a = 0; a < 5; a++ { // Normal "for" loop
		fmt.Printf("The value of a : %d\n", a)
	}

	for a < b { // working like "while" loop
		a++
		fmt.Printf("Value of a : %d\n", a)
	}

	for i, x := range numbers { // Range takes 1st arg as index and 2nd arg as variable
		fmt.Printf("Value of x at %d is %d\n", i, x)
	}
}

// "break" - terminate the loop using break statement
// "continue" - skip the current iteration and continue to the next iteration
// IMPORTANT - terminate an infinite loop by pressing Ctrl + C
