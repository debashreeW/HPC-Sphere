package main

import "fmt"

func main() {
	var a, b = 5, "foo" // multiple variables initialized together
	var c = 2.1         // by default float64 (STATIC declaration)
	d := 3              // without var, declared like this (DYNAMIC declaration)

	//PI = 3.14					// This caused error - undefined PI
	//PI := 3.14				// This caused error - PI declared but not used
	//const PI = 3.14			// Here also, PI declared but not used, but will just show warning and continue to run
	// Constants should be written in CAPITALS

	fmt.Printf("a is %d of type %T and b is \"%s\" of type %T \n", a, a, b, b)
	fmt.Printf("c is %f of type %T \n", c, c)
	fmt.Println(d)
}
