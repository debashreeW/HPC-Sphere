//One can increase the capacity of a slice using the append() function. Using copy()function, the contents of a source slice are copied to a destination slice.

//cap() tells max elements slice can hold, len() tell currently how many elements are contained

//append causes cap to double to the min number so as to hold all existing elements
package main

import "fmt"

func main() {
	s1 := []int{10, 20, 30, 40, 50}
	sliceDetails(s1)

	sliceDetails(s1[0:3])
	sliceDetails(s1[2:])
	sliceDetails(s1[:4])

	fmt.Println("--------------------------------")
}
func sliceDetails(a []int) {
	fmt.Println("--------------------------------")
	fmt.Printf("The slice %v has len = %d and capacity = %d\n", a, len(a), cap(a))
}
