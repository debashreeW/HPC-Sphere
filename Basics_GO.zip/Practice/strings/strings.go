// Separate words from strings as per given separator

package main

import "fmt"

func main() {
	var greeting = "Good morning to all!"
	//	fmt.Printf("%d %v %T", greeting[16], greeting[16], greeting[16])

	new_arr := strToArr(greeting, ' ')
	showArray(new_arr)

	new_arr = strToArr("This,is another,statement!", ',')
	showArray(new_arr)
}

func strToArr(myarray string, separator rune) []string {
	l := 0
	var newarr []string
	for i, c := range myarray {
		if c == separator {
			newarr = append(newarr, myarray[l:i])
			l = i + 1
		}

	}
	newarr = append(newarr, myarray[l:])
	return newarr

}
func showArray(newarr []string) {
	fmt.Println("----------------------------------------------------")
	for _, arr := range newarr {
		fmt.Println(arr)
	}
}
