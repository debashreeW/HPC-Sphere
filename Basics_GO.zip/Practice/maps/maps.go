package main

import "fmt"

func main() {
	fmt.Println("------------------------------")

	//make a new map
	squareRoots := make(map[int]string)

	//Adding entries to map
	squareRoots[9] = "Three"
	squareRoots[16] = "Four"
	squareRoots[25] = "Five"

	//Print the map
	for i, s := range squareRoots {
		fmt.Printf("The square root of %d is %s\n", i, s)
	}
	fmt.Println("------------------------------")

	//Testing if value for key is available or not
	val, ok := squareRoots[8]
	if ok {
		fmt.Printf("The square root is %s\n", val)
	} else {
		fmt.Println("Square root not available")
	}
	fmt.Println("------------------------------")

	//Delete an entry
	delete(squareRoots, 16)

	//Regenerate map
	for i, s := range squareRoots {
		fmt.Printf("The square root of %d is %s\n", i, s)
	}
	fmt.Println("------------------------------")
}
