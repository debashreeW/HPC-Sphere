code taken from -> https://medium.com/technofunnel/polymorphism-with-golang-interfaces-b2f58a05b221

	Since we can create a variable of type “interface” and assign “struct” object to it, it provides further added advantage of assigning an object of different types to an interface 	which fulfils the functional contract and invokes the function from it and hence enabling the feature of Polymorphism.

	Once we have any type declared like “Manager” and/or "Lead" that contains all the functional requirement for the “Employee” Interface contract, we can then create their objects and 	can assign them to the “interface” variable. 

	A comman interface variable can hold multiple objects of different types, as long as they fulfil interface requirements - i.e., all the methods of the interface must be defined by the underlying objects.