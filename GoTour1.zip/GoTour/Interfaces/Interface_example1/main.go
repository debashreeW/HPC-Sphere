package main

import "fmt"

// Creating a Simple Interface "Employee"
type Employee interface {
	GetDetails()
	GetEmployeeSalary() int
}

// Creating a new type "Manager" containing all functions required by "Employee" Interface
type Manager struct {
	Name        string
	Age         int
	Designation string
	Salary      int
}

func (mgr Manager) GetDetails() {
	fmt.Printf("Name : %v, Age: %v is the %v\n", mgr.Name, mgr.Age, mgr.Designation)
}

func (mgr Manager) GetEmployeeSalary() int {
	return mgr.Salary
}

// Creating a new type "Lead" containing all functions required by "Employee" Interface
type Lead struct {
	Name     string
	Age      int
	TeamSize string
	Salary   int
}

func (ld Lead) GetDetails() {
	fmt.Printf("Name : %v, Age: %v is working on teamsize of %v\n", ld.Name, ld.Age, ld.TeamSize)
}

func (ld Lead) GetEmployeeSalary() int {
	return ld.Salary
}

func main() {
	fmt.Println("-----------------------------------------------")
	// New variable of type "Employee" created
	var employeeInterface Employee

	//Object of Type Manager
	newManager := Manager{Name: "Manager", Age: 35, Designation: "Developer", Salary: 50}

	//Manager Object assigned to Interface type since Interface Contract is satisfied
	employeeInterface = newManager

	// Invoke Functions that belong to Interface "Employee"
	employeeInterface.GetDetails()
	fmt.Printf("Employee's Salary is : %v\n", employeeInterface.GetEmployeeSalary())
	fmt.Println("-----------------------------------------------")

	newLead := Lead{Name: "Team Lead", Age: 26, TeamSize: "30", Salary: 30}
	employeeInterface = newLead

	employeeInterface.GetDetails()
	fmt.Printf("Employee's Salary is : %v\n", employeeInterface.GetEmployeeSalary())
	fmt.Println("-----------------------------------------------")
}
