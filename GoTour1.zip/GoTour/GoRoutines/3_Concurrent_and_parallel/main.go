package main

import (
	"fmt"
	"runtime"
	"time"
)

func main() {
	runtime.GOMAXPROCS(4)
	start := time.Now().Local().UTC().UnixNano()
	//	fmt.Println(start)
	go func() {
		for i := 0; i < 3; i++ {
			fmt.Println(i)
		}
	}()

	go func() {
		for i := 0; i < 3; i++ {
			fmt.Println(i)
		}
	}()

	end := time.Now().Local().UTC().UnixNano()
	//	fmt.Println(end)
	elapsedTime := end - start

	fmt.Print("Total Time For Execution (nanosec): ")
	fmt.Println(elapsedTime)

	time.Sleep(time.Second)
}
