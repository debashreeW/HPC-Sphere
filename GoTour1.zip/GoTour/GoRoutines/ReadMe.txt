Code taken from ->
https://medium.com/technofunnel/understanding-golang-and-goroutines-72ac3c9a014d

----------------------------------------------------------------------------------------

#keyword "go" for concurrency -> (2_Concurrent)
	We can add the Goroutine to the Go program by adding the keyword go in front of the function execution.
	Once we add the go keyword in front of the self-executing function, we are adding concurrency to the execution.

	In the above code, we added a keyword go in front of the function execution. When the keyword is added to the function execution, it creates a separate Goroutine for the function 	execution and that function is executed inside a separate Goroutine thread.
	In the above execution, adding go in front of the functions created a separate thread for its execution rather than executing it in the same thread. Hence, adding concurrency and 	boosting performance.

----------------------------------------------------------------------------------------

parallel processing -> (3_Concurrent_and_parallel)
	In Go, we can add an execution core with this simple line of code:	"runtime.GOMAXPROCS(4)"

	This will instruct the application to scale up on multiple cores. Here we have specified that the application can use four cores for the execution.
	Once we create Goroutines, they can be executed together in different cores, enabling parallel processing and speeding up the application.

	When we add GOMAXPROCS, we are asking the application to scale up the application on multiple cores.
	Now, when the go keywords are added in front of the function execution, they can run separately on different cores and boost up the performance of the application.
	Here, we are adding concurrency with parallelism.

