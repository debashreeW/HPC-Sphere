// We can take user input by entering them at command line using os.Args

package main

import (
	"fmt"
	"os"
	"strconv"
	// "strings"
)

func main() {

	fmt.Println(os.Args[0]) //name of the command itself
	fmt.Println(os.Args[1]) //Arguments passed

	fmt.Printf("The command-line argument entered is : %v of type \"%T\"\n", os.Args[1], os.Args[1])
	num, _ := strconv.Atoi(os.Args[1])
	//fmt.Printf("%T\n", num)
	if num%2 == 0 {
		fmt.Println("It is an Even No")
	} else {
		fmt.Println("It is an Odd No")
	}
}

// Run as -> go run printCmdLines.go hello
//hello is the argument, it will be printed
