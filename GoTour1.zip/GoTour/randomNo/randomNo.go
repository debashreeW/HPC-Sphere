package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	rand.Seed(time.Now().UnixNano())

	/* if you dont write above code of rand.Seed(), The random func will although generate one set of random number for each call, but everytime you run the code, it will generate same set of random numbers.

	This is because by default the seed is always the same, the number 1. To actually get a random number, you need to provide a unique seed for your program.

	The most used seed is the current time, converted to int64 by UnixNano with rand.Seed(time.Now().UnixNano())*/

	fmt.Println("My favorite number is", rand.Intn(10))
	fmt.Println("My favorite number is", rand.Intn(10))
	fmt.Println("My favorite number is", rand.Intn(10))
	fmt.Println("My favorite number is", rand.Intn(10))
}
