package main

import "fmt"

func main() {
	var m1 map[int]string
	NilTest(m1)

	// This will throw error - > "entry in nil map"
	// m1[0] = "hello"
	// m1[1] = "world"
	ShowMap(m1)
	fmt.Println("----------------------------------")

	var m2 = make(map[int]string) // Initialize using make() - Not a nil map, but map with zero key-value pairs
	NilTest(m2)
	m2[0] = "hello" // Adding items (key-value pairs) to a map
	m2[1] = "world"
	ShowMap(m2)
	fmt.Println("----------------------------------")

	var m3 = map[string]string{ // declare as well initialize
		"a": "hello",
		"b": "world",
	}
	m3["c"] = "!"      // Adding items (key-value pairs) to a map
	m3["b"] = "People" // Overwriting old m2[1] entry
	//ShowMap(m3)
	fmt.Println(m3)
	fmt.Println("----------------------------------")

	/* let */
	m3["d"] = ""
	fmt.Printf("m3[3] = \"%v\"\n", m3["d"])
	fmt.Printf("m3[4] = \"%v\"\n", m3["x"]) // It will also print blank even if "4" is not a valid key

	_, ok := m3["d"]
	fmt.Println(ok) // key found - result TRUE

	_, ok = m3["x"]
	fmt.Println(ok) // key not found - result FALSE

	fmt.Println("----------------------------------")

	fmt.Println("Finally map -> ")
	fmt.Printf("\t%v\n", m3)

	delete(m3, "c")

	fmt.Println("After deletion, map -> (key \"c\" deleted) ")
	fmt.Printf("\t%v\n", m3)
	fmt.Println("----------------------------------")
	//==============================================================================

}

func Test(a interface{}) {
	fmt.Printf("Map : %v of type : %T", a, a)

}

func NilTest(a map[int]string) {
	if a == nil {
		fmt.Println("Map is NIL")
	} else {
		fmt.Println("Map is NOT NIL")
	}
}
func ShowMap(a map[int]string) {
	fmt.Println(a)
}
