//IMPORTANT : If a struct contains another struct (nested-structs), the outer struct can access the methods (directly using its own variable) defined on inner struct but not vice-versa!

//Example: If outerStruct contains innerStruct, and innerStruct has a field "num", then innerStruct accesses it by "innerStruct.num", while outerStruct will access it using "outerStruct.innerStruct.num" or even directly as "outerStruct.num"

package main

import "fmt"

type Person struct {
	name string
}

func (p Person) Talk() string {
	return "The contestant's name is " + p.name
}

type SoccerPlayer struct {
	Person
	lifeGoal string
}

// func (s SoccerPlayer) Inspire() string {
// 	return "My life goal is to " + s.lifeGoal
// }

func (s SoccerPlayer) Inspire() string {
	return fmt.Sprintf("%v's life's goal is to %v", s.name, s.lifeGoal)
}

func main() {
	fmt.Println("----------------------------------------------")

	rose := Person{"Rose"}
	fmt.Println(rose)

	s := SoccerPlayer{rose, "wins a world cup"} // SoccerPlayer contains Person (rose) struct : example of Nested structs
	fmt.Println(s)
	//fmt.Printf("%v %T\n", s, s)

	fmt.Println("----------------------------------------------")

	fmt.Println(rose.Talk())
	//fmt.Println(rose.Inspire()) //Error : rose.Inspire undefined (type Person has no field or method Inspire)

	fmt.Println("----------------------------------------------")

	fmt.Println(s.Talk()) // NOTE here : although Talk() method is defined on Person, since it is contained in SoccerPlayer "s", "s" can directly call it!
	fmt.Println(s.Inspire())

	fmt.Println("----------------------------------------------")
}
