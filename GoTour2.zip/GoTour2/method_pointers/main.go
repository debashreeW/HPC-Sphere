//IMPORTANT : A method with a pointer receiver can accept both a pointer and a value as the receiver argument. But, a function with a pointer argument can only accept a pointer

package main

import "fmt"

type Point struct {
	x, y int
}

func (p Point) translateX(x1 int) {
	p.x += x1
}
func (p *Point) translateY(y1 int) {
	p.y += y1
}
func main() {
	p := Point{2, 4}
	fmt.Println(p)

	p.translateX(10) //method without pointer receiver
	fmt.Println("After translate X by 10 --> ")
	fmt.Println(p)

	p.translateY(10) //method with pointer receiver, passed value as the receiver argument

	ptr := &p
	ptr.translateY(10) //method with pointer receiver, passed pointer as the receiver argument
	//In both approaches, action is executed correctly. Since Go knows that the method Translate() has a pointer receiver, it interprets the statement p.Translate() as (&p).Translate(). It’s a syntactic sugar provider by Go for convenience.

	fmt.Println("After translate Y by 10 --> ")
	fmt.Println(p)
}
