package main

import "fmt"

func main() {
	src := []string{"Hello", "Hi", "How", "are", "you"}
	dest := make([]string, 2)

	//COPY function
	no_of_elements := copy(dest, src)
	fmt.Println(src)
	fmt.Println(dest)
	fmt.Println(no_of_elements)
	fmt.Println("----------------------------------------------")

	//Append function
	src = append(dest, "I", "am", "well") //	replaces current data with appended data
	fmt.Println(src)
	fmt.Println(dest)

	//You can directly append one slice to another using the ... operator. This operator expands the slice to a list of arguments.

	// newslice := append(src, dest)	// Gives error => "cannot use dest (type []string) as type string in append"
	newslice := append(src, dest...)
	fmt.Println(newslice)
}
