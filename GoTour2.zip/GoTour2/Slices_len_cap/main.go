package main

import "fmt"

func main() {
	s := []int{10, 20, 30, 40, 50, 60, 70, 80, 90, 100}
	fmt.Println("Original Slice") // Basically s[0:10] -> 10-0=10 max capacity => next range b/w 0:10
	fmt.Printf("s = %v, len = %d, cap = %d\n", s, len(s), cap(s))

	s = s[1:5] // 10-1=9 max capacity => next range b/w 0:9
	fmt.Println("\nAfter slicing from index 1 to 5")
	fmt.Printf("s = %v, len = %d, cap = %d\n", s, len(s), cap(s))

	s = s[:8] // basically s[0:8] -> 9-0=9 max capacity => next range b/w 0:9
	fmt.Println("\nAfter extending the length")
	fmt.Printf("s = %v, len = %d, cap = %d\n", s, len(s), cap(s))

	s = s[2:] // 9-2 = 7 max capacity => next range b/w 0:7
	fmt.Println("\nAfter dropping the first two elements")
	fmt.Printf("s = %v, len = %d, cap = %d\n", s, len(s), cap(s))

	s = s[4:7] // 7-4 = 3 max capacity => next range b/w 0:3
	fmt.Printf("s = %v, len = %d, cap = %d\n", s, len(s), cap(s))

	s = s[2:3]
	fmt.Printf("s = %v, len = %d, cap = %d\n", s, len(s), cap(s))

	fmt.Println("----------------------------------------------")
	// Using inbuilt function "make" to create an array of size 10(capacity), slice it till index 5(length), and return the slice reference
	// make([]T,len,cap)
	//If cap not defined explicitly in make(), cap is automatically equal to len
	a := make([]int, 5, 10)
	fmt.Printf("s = %v, len = %d, cap = %d\n", a, len(a), cap(a))
}
