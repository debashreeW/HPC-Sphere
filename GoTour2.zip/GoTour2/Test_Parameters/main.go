// The interface{} type, the empty interface, is the source of much confusion. The interface{} type is the interface that has no methods. Since there is no implements keyword, all types implement at least zero methods, and satisfying an interface is done automatically, all types satisfy the empty interface. That means that if you write a function that takes an interface{} value as a parameter, you can supply that function with any value. So, this function:

// func DoSomething(v interface{}) {
//    // ...
// }
// will accept any parameter whatsoever.

package main

import (
	"fmt"
	"os"
)

func test(i interface{}) {
	fmt.Printf("Input : \"%v\" --> \n", i)
	switch i.(type) { //Always "string" case will be selected in this case as os arguments are always strings
	case int:
		fmt.Println("INT argument(s) entered!")
		fmt.Println("--------------------------------------")
	case float32, float64:
		fmt.Println("FLOAT argument(s) entered!")
		fmt.Println("--------------------------------------")
	case string:
		fmt.Println("STRING argument(s) entered!")
		fmt.Println("--------------------------------------")
	case []int:
		fmt.Println("[]INT argument(s) entered!")
		fmt.Println()
		// Below code will throw error : "cannot range over i (type interface {})"

		// for _, x := range i {
		// 	fmt.Printf("%d ", x)
		// }

		// So we will have to convert it to an array/slice first

		fmt.Println("To access individual items of []int, convert the numbers into slice from interface type ... ")
		vals := i.([]int) // Converts the interface to integer slice/array

		for _, x := range vals { // Now we can use "range" to go through its elements
			fmt.Printf("%d ", x)
		}
		fmt.Println()
		fmt.Println("--------------------------------------")
	default:
		fmt.Println("argument(s) type unknown!")
		fmt.Println("--------------------------------------")
	}
}

func main() {

	fmt.Println("--------------------------------------")
	if len(os.Args) > 1 {
		x := ""
		for i := 1; i < len(os.Args); i++ {
			x += os.Args[i]
			if i != (len(os.Args) - 1) {
				x += " "
			}
		}
		test(x)
	}

	test(2)
	test("hello")
	test(true) // bool type

	nums := []int{10, 20, 30}

	test(nums)

}
