package main

import "fmt"

func addAllInts(nums ...int) int {
	total := 0
	for _, v := range nums {
		total += v
	}
	return total
}

func main() {
	fmt.Println(addAllInts(1, 2, 3, 4)) // Example of a variadic function - that take an artibrary number of arguments.

	points := []int{5, 10, 15}
	fmt.Println(addAllArr(points...)) // Variadic functions can be invoked with a slice of arguments as well.
}

func addAllArr(nums ...int) int {
	total := 0
	for _, v := range nums {
		total += v
	}
	return total
}
