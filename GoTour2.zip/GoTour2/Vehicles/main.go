package main

import "fmt"

type Vehicle interface {
	getWheels() int
	getDetails() string
	getCost() float64
}

type TwoWheeler struct {
	name  string
	color string
	price float64
}

func (t2 TwoWheeler) getWheels() int {
	return 2
}
func (t2 TwoWheeler) getDetails() string {
	return fmt.Sprintf("Name : %v - Color : %v\n", t2.name, t2.color)
}
func (t2 TwoWheeler) getCost() float64 {
	return t2.price
}

type FourWheeler struct {
	name  string
	color string
	price float64
}

func (t4 FourWheeler) getWheels() int {
	return 4
}
func (t4 FourWheeler) getDetails() string {
	return fmt.Sprintf("Name : %v - Color : %v\n", t4.name, t4.color)
}
func (t4 FourWheeler) getCost() float64 {
	return t4.price
}

type SixWheeler struct {
	name  string
	color string
	price float64
}

func (t6 SixWheeler) getWheels() int {
	return 6
}
func (t6 SixWheeler) getDetails() string {
	return fmt.Sprintf("Name : %v - Color : %v\n", t6.name, t6.color)
}
func (t6 SixWheeler) getCost() float64 {
	return t6.price
}

func main() {
	fmt.Println("--------------------------------------------------")
	var vh1, vh2, vh3 Vehicle

	scooty := TwoWheeler{"Activa", "Blue", 50000}

	car := FourWheeler{"i10", "Grey", 300000}

	truck := SixWheeler{"Tata Signa", "Red", 400000}

	vh1 = scooty
	fmt.Println(vh1.getDetails())
	fmt.Printf("It has %v wheels.\n", vh1.getWheels())
	fmt.Println("--------------------------------------------------")

	vh2 = car
	fmt.Println(vh2.getDetails())
	fmt.Printf("It has %v wheels.\n", vh2.getWheels())
	fmt.Println("--------------------------------------------------")

	vh3 = truck
	fmt.Println(vh3.getDetails())
	fmt.Printf("It has %v wheels.\n", vh3.getWheels())
	fmt.Println("--------------------------------------------------")

	fmt.Printf("Total cost of all vehicles is : %v\n", getTotalCost(vh1, vh2, vh3))

	vehicles1 := []Vehicle{scooty, car}
	//We can also write this as:-
	//vehicles1 := []Vehicle{TwoWheeler{"Jupiter", "Green", 40000}, FourWheeler{"Santro", "Yellow", 350000}}

	total := 0.0
	for _, a := range vehicles1 {
		total += a.getCost()
	}
	fmt.Printf("The cost of small vehicles is : %v \n", total)
}

func getTotalCost(vh ...Vehicle) float64 {
	total := 0.0
	for _, c := range vh {
		total += c.getCost()
	}
	return total
}
