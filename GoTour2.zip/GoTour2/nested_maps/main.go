// REMEMBER: Maps are unordered data structure. The order of outputs may differ, but the key-value pairs shall remain the same

package main

import "fmt"

func main() {
	nested_map := map[string]map[string]string{
		"red": {
			"element": "fire",
			"feeling": "hot",
		},
		"blue": {
			"element": "water",
			"feeling": "cold",
		},
	}
	//fmt.Println(nested_map["blue"]["feeling"])

	for key1, val1 := range nested_map {
		fmt.Printf("\"%v\"\n", key1)
		for key2, val2 := range val1 {
			fmt.Printf("\t\"%v\" : \"%v\"\n", key2, val2)
		}
	}
}
