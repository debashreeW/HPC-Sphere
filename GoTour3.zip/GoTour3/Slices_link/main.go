package main

import (
	"fmt"
)

func linked() (int, int, int) {
	s1 := []int{1, 2, 3, 4, 5}
	s2 := s1    //	Deep copy
	s3 := s1[:] //Deep copy
	s1[3] = 99
	return s1[3], s2[3], s3[3]
}

func noLink() (int, int) {
	s1 := []int{1, 2, 3, 4, 5}
	s2 := s1           // Deep copy, cap = len = 5
	s1 = append(s1, 6) // capacity breached, s1 now pointing to new hidden array
	s1[3] = 99
	return s1[3], s2[3]
}

func capLinked() (int, int) {
	s1 := make([]int, 5, 10)
	s1[0], s1[1], s1[2], s1[3], s1[4] = 1, 2, 3, 4, 5
	s2 := s1           // Deep copy, cap = 10 (set by make() function)
	s1 = append(s1, 6) // within capacity, still pointing to same hidden array as of s1
	s1[3] = 99
	return s1[3], s2[3]
}

func capNoLink() (int, int) {
	s1 := make([]int, 5, 10)
	s1[0], s1[1], s1[2], s1[3], s1[4] = 1, 2, 3, 4, 5
	s2 := s1                          // deep copy, cap = 10
	s1 = append(s1, []int{10: 11}...) // cap breached due to 11th new entry(index:10); pointing to new array now
	s1[3] = 99
	return s1[3], s2[3]
}

func copyNoLink() (int, int, int) {
	s1 := []int{1, 2, 3, 4, 5}
	s2 := make([]int, len(s1)) // empty slice, with len = len(s1) = 5
	copied := copy(s2, s1)     // shallow copy
	s1[3] = 99
	return s1[3], s2[3], copied
}

func appendNoLink() (int, int) {
	s1 := []int{1, 2, 3, 4, 5}
	s2 := append([]int{}, s1...) // appending s1 to some new hidden array, given by []int{}
	s1[3] = 99
	return s1[3], s2[3]
}

func main() {
	l1, l2, l3 := linked()
	fmt.Println("Linked :", l1, l2, l3)
	nl1, nl2 := noLink()
	fmt.Println("No Link :", nl1, nl2)
	cl1, cl2 := capLinked()
	fmt.Println("Cap Link :", cl1, cl2)
	cnl1, cnl2 := capNoLink()
	fmt.Println("Cap No Link :", cnl1, cnl2)
	copy1, copy2, copied := copyNoLink()
	fmt.Print("Copy No Link: ", copy1, copy2)
	fmt.Printf(" (Number of elements copied %v)\n", copied)
	a1, a2 := appendNoLink()
	fmt.Println("Append No Link:", a1, a2)

	// if len(os.Args) > 1 {
	// 	s := os.Args[1]
	// 	map1 := map[string]string{
	// 		"305": "Sue",
	// 		"204": "Bob",
	// 		"631": "Jake",
	// 		"073": "Tracy",
	// 	}

	// 	for key := range map1 {
	// 		if key == s {
	// 			fmt.Printf("%v - %v\n", key, map1[key])
	// 			break
	// 		}
	// 	}

	// 	_, ok := map1[s]
	// 	if !ok {
	// 		fmt.Println("Key not found")
	// 	} else {
	// 		fmt.Printf("%v - %v\n", s, map1[s])
	// 	}
	// }

	maps := map[int]string{
		1:   "one",
		20:  "twenty",
		300: "three hundred",
	}
	// maps[1] = "one"
	// maps[20] = "twenty"
	fmt.Println(maps)

	delete(maps, 20)
	fmt.Println(maps)
}
