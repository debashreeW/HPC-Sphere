package main

import (
	"errors"
	"fmt"
)

// func doubler(v interface{}) (string, error) {
// 	if i, ok := v.(int); ok {
// 		return fmt.Sprint(i * 2), nil
// 	}

// 	if s, ok := v.(string); ok {
// 		return s + s, nil
// 	}

// 	return "", errors.New("Unsupported type passed!")
// }

func doubler(v interface{}) (string, error) {
	switch t := v.(type) {
	case int, uint:
		return fmt.Sprint(t.(int) * 2), nil

	case string:
		return t + t, nil

	case bool:
		if t {
			return "true true", nil
		} else {
			return "false false", nil
		}

	case float32, float64: // For the floats, we're matching on more than one type. This means we need to do type assertion to be able to work with the value
		if f, ok := t.(float64); ok {
			return fmt.Sprint(f * 2), nil
		}
		return fmt.Sprint(t.(float32) * 2), nil
	}

	return "", errors.New("Unsupported type passed!")
}

func main() {
	res, _ := doubler(5)
	fmt.Println("5 : ", res)

	res, _ = doubler(-5)
	fmt.Println("-5 : ", res)

	res, _ = doubler("mum")
	fmt.Println("mum : ", res)

	res, _ = doubler(float32(3.14))
	fmt.Println("3.14 : ", res)

	res, _ = doubler(true)
	fmt.Println("true : ", res)

}
