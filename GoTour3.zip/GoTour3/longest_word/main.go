package main

import (
	"fmt"
	"os"
)

func getArgs(min int) []string {
	if len(os.Args) < (min + 1) {
		fmt.Printf("Min of %v arguments are required\n", min)
		os.Exit(1)
	}
	var args []string
	for i := 0; i < len(os.Args); i++ {
		args = append(args, os.Args[i])
	}
	return args
}

func longestWord(args []string) []string {
	longest := ""
	var long_arr []string
	for i := 1; i < len(args); i++ {
		if len(args[i]) == len(longest) {

			long_arr = append(long_arr, args[i])
		}

		if len(args[i]) > len(longest) {

			longest = args[i]
			if len(long_arr) == 0 {
				long_arr = append(long_arr, args[i])
			} else {
				long_arr = long_arr[0:1]

				long_arr[0] = args[i]

			}
			//fmt.Println(long_arr)
		}
	}

	return long_arr
}

func main() {
	if longest := longestWord(getArgs(2)); len(longest) > 0 {
		fmt.Println("The longest word in CLI is : ", longest)
	} else {
		fmt.Println("Error occurred!")
	}

}
