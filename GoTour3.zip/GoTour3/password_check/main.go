package main

import (
	"fmt"
	"os"
	"unicode"
)

func passwordChecker(pw string) bool {
	//fmt.Println(pw)
	pw_rune := []rune(pw)
	//fmt.Println(pw_rune)
	if len(pw_rune) < 8 {
		return false
	}
	hasUpper := false
	hasLower := false
	hasNumber := false
	hasSymbol := false

	for _, v := range pw_rune {
		if unicode.IsUpper(v) {
			hasUpper = true
		}
		if unicode.IsLower(v) {
			hasLower = true
		}
		if unicode.IsNumber(v) {
			hasNumber = true
		}
		if unicode.IsPunct(v) || unicode.IsSymbol(v) {
			hasSymbol = true
		}
	}

	return hasUpper && hasLower && hasNumber && hasSymbol
}

func main() {
	if passwordChecker("") {
		fmt.Println("password good")
	} else {
		fmt.Println("password bad")
	}

	v := ""
	if len(os.Args) > 1 {
		if len(os.Args) < 3 {
			v = os.Args[1]
			if passwordChecker(v) {
				fmt.Println("password good")
			} else {
				fmt.Println("password bad")
			}
		} else {
			fmt.Println("There can't be space in between password!")
		}
	}

	for i := 0; i < len(v); i++ {
		fmt.Print(v[i], " ")
	}
	fmt.Println()
	for i := 0; i < len(v); i++ {
		fmt.Print(string(v[i]), " ")
	}
	fmt.Println()

}
